import React from "react";
import ContactUs from "../components/ContactSection";
import ScrolltoTop from "../components/ScrollToTop";

const contact = () => {
  return (
    <>
      <ScrolltoTop />
      <ContactUs />
    </>
  );
};

export default contact;
