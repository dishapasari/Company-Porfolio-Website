import React from 'react'
import CareersSection from '../components/CareersSection'

const Careers = () => {
    return (
        <>
            <CareersSection />  
        </>
    )
}

export default Careers
